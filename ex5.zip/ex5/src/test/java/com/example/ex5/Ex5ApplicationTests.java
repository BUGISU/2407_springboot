package com.example.ex5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
